public class PaireChaineEntier {

    private String chaine;
    private int entier;

    //constructeur
    public PaireChaineEntier(String chaine, int entier){
        this.chaine = chaine;
        this.entier = entier;
    }

    //getteur
    public String getChaine(){
        return chaine;
    }

    public void setChaine(String chaine){this.chaine = chaine;}
    public int getEntier(){
        return entier;
    }

    public void setEntier(int entier){
        this.entier = entier;
    }

    @Override
    public String toString(){
        return chaine + " : "+ entier;
    }

    public int compareTo(PaireChaineEntier o){
        if (this.entier < o.entier){
            return -1;
        }else if(this.entier == o.entier){
            if (this.chaine.compareTo(o.chaine) < 0){
                return -1;
            }else if (this.chaine.compareTo(o.chaine) == 0){
                return 0;
            }else {
                return 1;
            }

        }else {
            return 1;
        }
    }
}
