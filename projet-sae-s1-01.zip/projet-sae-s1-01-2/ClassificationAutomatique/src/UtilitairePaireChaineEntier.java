import java.util.ArrayList;

public class UtilitairePaireChaineEntier {


    public static int indicePourChaine(ArrayList<PaireChaineEntier> listePaires, String chaine) {
        //indice pour PaireChaineEntier pour chaine

            int  ind = -1;      //-1 si la chaine n'est pas dans listePaires
            for (int i = 0; i < listePaires.size(); i++) {  //parcour de la listePaires
                if (listePaires.get(i).getChaine().equalsIgnoreCase(chaine)) { //si la chaine courante de listePaire est egale a la chaine voulu
                    ind = i;            //ind prend alors la valeur de l'indice de cette chaine
                }
            }
            return ind;

//        int inf = 0;
//        int sup = listePaires.size()-1; // invariant vérifié
//        int m;
//        while (inf < sup) {
//            m = (inf + sup) / 2;
//            // invariant vérifié
//            if (listePaires.get(m).getChaine().compareTo(chaine) >= 0) { // v[m] ≥ val
//                sup = m; // continuer de chercher à gauche sur [inf..m-1]
//            } else { // v[m] < val
//                inf = m + 1; // continuer de chercher à droite sur [m+1..sup-1]
//            }
//            // invariant vérifié
//        }
//        // inf = sup
//        if (listePaires.get(sup).getChaine().compareTo(chaine) == 0) {
//            return listePaires.get(sup).getEntier(); // val trouvée
//        } else {
//            return -1; // val pas trouvée, val aurait été à l'indice sup
//        }

    }

    public static int entierPourChaine(ArrayList<PaireChaineEntier> listePaires, String chaine) {
        //valeur de l'entier pour la string chaine donnée, recherche dans la ListePaires
        int i = 0;
        while(i <= (listePaires.size() - 1) && !listePaires.get(i).getChaine().equalsIgnoreCase(chaine)) {   //tant que i n'a pas parcouru l'ensemble de listePaire et
            i++;                                                                                            //et que la chaine courante de listePaire n'est pas egale à la chaine demandée
        }
        if (listePaires.get(i).getChaine().equalsIgnoreCase(chaine)){       //si la chaine courante de listePaire est egale à la chaine courante
            return listePaires.get(i).getEntier();                          //return l'entier associer à cette chaine
        }else {
            return 0;                                                       //return 0 si non trouvée
        }
    }

    public static String chaineMax(ArrayList<PaireChaineEntier> listePaires)
            //retourne la chaine avec le plus grand entier dans le lexique listePaires
    {
        int plusGrand = listePaires.get(0).getEntier(); //prendra la valeur de l'entier le plus grand
        String chaine = listePaires.get(0).getChaine(); //prendra la valeur de la chaine le plus grand

        for(int i = 0;i < listePaires.size();i++){
            int entierCour = listePaires.get(i).getEntier();        //parcour de la listePaires donnée est attribution
            if (entierCour > plusGrand){                            //de l'entier le plus grand pour chaque tour de boucle
                plusGrand = listePaires.get(i).getEntier();
                chaine = listePaires.get(i).getChaine();            //chaine prend la valeur de la chaineCourante
            }
        }
        return chaine;
    }


    public static float moyenne(ArrayList<PaireChaineEntier> listePaires) {
        //qui retourne la moyenne des entiers stockés dans listePaires.
        float somme = 0; //liste des entiers de liste paire
        int nbInt = 0; //nombre d'entiers additionés
        for (int i = 0; i < listePaires.size(); i++) {
            int entierCOUR = listePaires.get(i).getEntier();
            somme += entierCOUR;
            nbInt ++;
        }
        return somme/nbInt;

    }

//    private static void triBullesAmeliore(ArrayList<PaireChaineEntier> v) {
//        int j; // pour faire descendre la bulle
//        int i = 0;
//        boolean onAPermute = true; // pour rentrer au moins une fois dans l’itération
//        // v[0..i-1] trié et v[0..i-1] ≤ v[i..v.size()-1) [invariant]
//        while (onAPermute) {
//            j = v.size()-1; // indice du dernier élément départ descente de bulles
//            onAPermute = false; // sera passé à true si on permute pendant la descente
//            while (j > i) { // faire descendre la bulle jusqu’à i
//                            // si le suivant est strictement plus petit que le précédent permuter
//                if (v.get(j).compareTo(v.get(j-1)) < 0) {
//                    PaireChaineEntier temporaire = v.get(j); v.set(j, v.get(j-1)); v.set(j-1, temporaire);
//                    onAPermute = true; // on a permuté, le tri doit se poursuivre
//                }
//                // reculer j
//                j--;
//            }
//            // v[0..i] trié et v[0..i] ≤ v[i+1..v.size()-1)
//            // affichage du vecteur courant but pédagogique
//
//            // avancer i
//            i++;
//            // v[0..i-1] trié et v[0..i-1] ≤ v[i .. v.size()-1) [invariant]
//        }
//            // i = v.size()-1
//            // v[0..v.size()-2] trié et v[0..v.size()-2] ≤ v[v.size()-1..v.size()-1) => v trié
//    }

//    private static int indiceValDichoIterative(ArrayList<PaireChaineEntier> v, String val) {
//        // {v trié croissant non vide} =>
//        // {résultat = indice le plus à gauche de val si val est dans v ;
//        // -indice que val devrait occuper si val n’est pas dans v}
//        // v.[v.size()-1] ≥ val
//            int inf = 0;
//            int sup = v.size()-1; // invariant vérifié
//            int m;
//            while (inf < sup) {
//                m = (inf + sup) / 2;
//                // invariant vérifié
//                if (v.get(m).getChaine().compareTo(val) >= 0) { // v[m] ≥ val
//                    sup = m; // continuer de chercher à gauche sur [inf..m-1]
//                } else { // v[m] < val
//                    inf = m + 1; // continuer de chercher à droite sur [m+1..sup-1]
//                }
//            // invariant vérifié
//            }
//            // inf = sup
//            if (v.get(sup).getChaine().compareTo(val) == 0) {
//                return v.get(sup).getEntier(); // val trouvée
//            } else {
//                return -1; // val pas trouvée, val aurait été à l'indice sup
//            }
//        }
    }
