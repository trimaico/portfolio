import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Categorie {

    private String nom; // le nom de la catégorie p.ex : sport, politique,...
    private ArrayList<PaireChaineEntier> lexique; //le lexique de la catégorie

    // constructeur
    public Categorie(String nom) {
        this.nom = nom;
    }


    public String getNom() {
        return nom;
    }


    public  ArrayList<PaireChaineEntier> getLexique() {
        return lexique;
    }


    // initialisation du lexique de la catégorie à partir du contenu d'un fichier texte
    public void initLexique(String nomFichier){
        //initialisation d'un catégorie avec son lexique fournit avec nomFichier

        lexique = new ArrayList<>(); //attribution d'une liste vide a lexique

        try {
            // lecture du fichier d'entrée
            FileInputStream file = new FileInputStream(nomFichier);
            Scanner scanner = new Scanner(file);

                String ligne = scanner.nextLine();
                String chaine = ligne.substring(0,ligne.indexOf(":"));                      //lecture du première élément chaine de nomFichier
                String entier = ligne.substring(ligne.indexOf(":")+1);            //lecture du première élément entier de nomFichier
                PaireChaineEntier ChaineEntier = new PaireChaineEntier(chaine,Integer.parseInt(entier));
                lexique.add(ChaineEntier);                                                  //création est insertion de ChaineEntier dans la liste lexique
                while (scanner.hasNextLine() && !ligne.equals("")) {
                    ligne = scanner.nextLine();
                    chaine = ligne.substring(0,ligne.indexOf(":"));                         //réitération des premières étapes mais dans une boucle while
                    entier = ligne.substring(ligne.indexOf(":")+1);               //pour parcourir tous le fichier

                    ChaineEntier = new PaireChaineEntier(chaine,Integer.parseInt(entier));
                    lexique.add(ChaineEntier);                                              //ajout de chaque élément dans le lexique
                }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    public int score(Depeche d) {
//        qui retourne l’entier correspondant au score de la depêche d pour la catégorie surlaquelle l’appel est
//        réalisé. Pensez à utiliser l’attribut mots de la classe Depeche correspondant à un tableau contenant
//        les mots de la depêche.

        int score = 0;
        for (int x = 0; x < lexique.size(); x++) {          //représente le mot du lexique de la catégorie on parcours tous les mots du lexique
            for (int i = 0; i < d.getMots().size(); i++) {      //i représente le mot à lire dans la depêche, on parcours tous les mots de dépêche
                if (d.getMots().get(i).compareTo(lexique.get(x).getChaine()) == 0) {               //on compare le mot du lexique du thème séléctionné avec le mot de la dépêche
                    score += lexique.get(x).getEntier();
                }
            }
        }
        return score;
    }


}
