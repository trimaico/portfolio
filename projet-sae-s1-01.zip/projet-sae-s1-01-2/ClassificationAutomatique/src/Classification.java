import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.time.temporal.Temporal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Classification {


    private static ArrayList<Depeche> lectureDepeches(String nomFichier) {
        //creation d'un tableau de dépêches
        ArrayList<Depeche> depeches = new ArrayList<>();
        try {
            // lecture du fichier d'entrée
            FileInputStream file = new FileInputStream(nomFichier);
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String ligne = scanner.nextLine();
                String id = ligne.substring(3);
                ligne = scanner.nextLine();
                String date = ligne.substring(3);
                ligne = scanner.nextLine();
                String categorie = ligne.substring(3);
                ligne = scanner.nextLine();
                String lignes = ligne.substring(3);
                while (scanner.hasNextLine() && !ligne.equals("")) {
                    ligne = scanner.nextLine();
                    if (!ligne.equals("")) {
                        lignes = lignes + '\n' + ligne;
                    }
                }
                Depeche uneDepeche = new Depeche(id, date, categorie, lignes);
                depeches.add(uneDepeche);
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return depeches;
    }

    public static void classementDepeches(ArrayList<Depeche> depeches,ArrayList<Categorie> categories,String nomFichier) {
        ArrayList<PaireChaineEntier> scoreCategorie = new ArrayList<PaireChaineEntier>();       //Une catégorie et son score selon une dépêche
        int indiceCategorieScoreMax;
        String categorieMaxScore;
        ArrayList<ArrayList<PaireChaineEntier>> reussiteCategorie = new ArrayList<ArrayList<PaireChaineEntier>>();
        int moyenneCategorie;
        ArrayList<PaireChaineEntier> moyenneTotal = new ArrayList<>();
        for (int i = 0; i < categories.size(); i++) {
            reussiteCategorie.add(new ArrayList<>());
        }
        try {
            FileWriter file = new FileWriter(nomFichier);
            for (int i = 0; i < depeches.size(); i++) {
                for (int j = 0; j < categories.size(); j++) {
                    scoreCategorie.add(new PaireChaineEntier(categories.get(j).getNom(), categories.get(j).score(depeches.get(i))));            //on remplace à chaque tour de boucle score categorie avec le score pour chaque catégorie de la dépêche suivante
                    //System.out.println(categories.get(j).score(depeches.get(i)));
                }
                categorieMaxScore = UtilitairePaireChaineEntier.chaineMax(scoreCategorie);
                indiceCategorieScoreMax = UtilitairePaireChaineEntier.indicePourChaine(scoreCategorie, UtilitairePaireChaineEntier.chaineMax(scoreCategorie));        // indince du score max dans scoreCategorie
                if (categorieMaxScore.compareTo(depeches.get(i).getCategorie()) == 0) {
                    reussiteCategorie.get(indiceCategorieScoreMax).add( new PaireChaineEntier("", 1));//j'ajoute pour chaque catégorie la réussite(1) ou l'erreur(0) de la dépêche examinée
                }
                else {
                    reussiteCategorie.get(indiceCategorieScoreMax).add( new PaireChaineEntier("", 0));
                }
                file.write(i+1 + ":" + categorieMaxScore + "\n");     //Ici on écrit les 500 premières lignes dans le fichier texte
                scoreCategorie = new ArrayList<>();         //On reinitialise scoreCategorie pour le reremplir dans le prochain for j...
            }
            for (int i = 0; i < categories.size(); i++) {
                file.write(categories.get(i).getNom() + ":" + "       "+ UtilitairePaireChaineEntier.moyenne(reussiteCategorie.get(i)) * 100 +"%" + "\n");    // On fait les derniers ajouts dans le fichier
                moyenneCategorie = (int) (UtilitairePaireChaineEntier.moyenne(reussiteCategorie.get(i)) * 100);
                moyenneTotal.add(new PaireChaineEntier("", (int) (UtilitairePaireChaineEntier.moyenne(reussiteCategorie.get(i)) * 100)));
            }
            file.write("MOYENNE : " + UtilitairePaireChaineEntier.moyenne(moyenneTotal)+ "%" +"\n");
            file.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static ArrayList<PaireChaineEntier> initDico(ArrayList<Depeche> depeches, String categorie) {
        //qui retourne une ArrayList<PaireChaineEntier> contenant tous les mots présents dans au
        //moins une dépêche de la catégorie categorie. Attention, même si le mot est présent plusieurs fois, il ne
        //doit apparaître qu’une fois dans la ArrayList retournée. Dans les entiers, nous stockerons les scores
        //associés à chaque mot et dans un premier temps, nous initialiserons ce score à 0.

            ArrayList<PaireChaineEntier> resultat = new ArrayList<>();

            for (int i = 0; i < depeches.size(); i++) {   //boucle parcourant tous les depeches
                Depeche depeche = depeches.get(i);          //création d'un depeche depeche qui prend la premiere depeche de depeche;
                if (depeche.getCategorie().equalsIgnoreCase(categorie)) {    //si la catégorie de cette depeche et egal a la catégérie donné
                    ArrayList<String> motsDepeche = depeche.getMots();      //on crée une liste de string motDepeche = au mot de la premiere depeche de depeche
                    for (int j = 0; j < motsDepeche.size(); j++) {    //pour chaque mot de cette depeche
                        String mot = motsDepeche.get(j);            //le premier mot d'une depeche
                        boolean motExiste = false;
                        for (int k = 0; k < resultat.size(); k++) { //parcour de la list resulat
                            PaireChaineEntier paire = resultat.get(k);  //paire prend la valeur de k
                            if (mot.equals(paire.getChaine()) || mot.length() <= 2) {             //si le mot numero j de motsDepeche est egale au mot numero k de résultat
                                motExiste = true;                           //Le mot existe
                            }
                        }
                        if (!motExiste) { //si le mot numero j de motsDepeche n'est pas egale au mot numero k de résulat
                            PaireChaineEntier temp = new PaireChaineEntier(mot, 0); //temp prend la valeur de mot,0
                            resultat.add(temp); //resulat prend temp
                        }
                    }
                }
            }
            return resultat;
    }

    public static void calculScores(ArrayList<Depeche> depeches, String categorie, ArrayList<PaireChaineEntier> dictionnaire) {
        //qui met à jour les scores des mots présents dans dictionnaire. Lorsqu'un mot présent dans
        //dictionnaire apparaît dans une dépêche de depeches, son score est : décrémenté si la dépêche
        //n'est pas dans la catégorie categorie et incrémenté si la dépêche est dans la catégorie categorie.
        ArrayList<String> lesMots;
        String motCour;
        int indice;

        for (int i = 0; i < depeches.size(); i++) {
            lesMots = depeches.get(i).getMots();

            for (int j = 0; j < lesMots.size(); j++) {    // parcours des mots de la dépêche courante
                motCour = lesMots.get(j);
                indice = UtilitairePaireChaineEntier.indicePourChaine(dictionnaire, motCour);
                if (indice >= 0) {   //si le mot cour est présent dans dictionnaire alors indice aura donnera la position du motCour et sera supérieur a 0
                    if (categorie.compareTo(depeches.get(i).getCategorie()) == 0) {   //bonne catégorie ?
                        dictionnaire.get(indice).setEntier(dictionnaire.get(indice).getEntier() + 1); //incrémentation
                    } else {
                        dictionnaire.get(indice).setEntier(dictionnaire.get(indice).getEntier() - 1);
                    }
                }
            }
        }
    }

    public static int poidsPourScore(int score) {
        //qui retourne une valeur de poids (1,2 ou 3) en fonction du score score (à vous de décider quel poids
        //pour quel score)
        if(score < 3){
            return 1;
        } else if(score < 6){      //si le score donnée est de 1, 2 ou 3, le poid sera l'equivalent
            return 2;
        } else {
            return 3;
        }
    }

    public static void generationLexique(ArrayList<Depeche> depeches, String categorie, String nomFichier) {
        //qui crée pour la catégorie categorie le fichier lexique de nom nomFichier à partir du vecteur de
        //dépêches depeches. Cette méthode doit construire une ArrayList<PaireChaineEntier> avec
        //initDico, puis mettre à jour les scores dans ce vecteur avec calculScores et enfin utiliser le vecteur
        //résultant pour créer un fichier lexique en utilisant la fonction poidsPourScore. Prenez exemple sur la
        //classe ExempleEcritureFichier pour l’écriture dans un fichier

        try {
            ArrayList<PaireChaineEntier> dico = initDico(depeches, categorie);
            calculScores(depeches, categorie, dico);

            int j ; // pour faire descendre la bulle
            int i = 0;
            boolean onAPermute = true;
            while (onAPermute) {
                j = dico.size() - 1;
                onAPermute = false;
                while (j > i){
                    if (dico.get(j).getEntier() > (dico.get(j-1).getEntier())){
                        PaireChaineEntier temp = dico.get(j);
                        dico.set(j,dico.get(j-1));
                        dico.set(j-1, temp);
                        onAPermute = true;
                    }
                    j--;
                }
                i++;
            }



            FileWriter file = new FileWriter(nomFichier);

            for ( i = 0; i < dico.size(); i++) {
                file.write(dico.get(i).getChaine() + ":");
                file.write(poidsPourScore(dico.get(i).getEntier()) + "\n");
            }
            file.close();
        } catch(IOException e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        //Chargement des dépêches en mémoire

        long startTime = System.currentTimeMillis();
        System.out.println("chargement des dépêches");

        //test avec depeche
        ArrayList<Depeche> depeches = lectureDepeches("./depeches.txt");

        //test avec test
        ArrayList<Depeche> depeches = lectureDepeches("./test.txt");



//        for (int i = 0; i < depeches.size(); i++) {
//            depeches.get(i).afficher();
//        }


        //generation des lexiques écrit a la main

//        Categorie economie = new Categorie("ECONOMIE");
//        economie.initLexique("./lexique-economie.txt");
//
//        Categorie sports = new Categorie("SPORTS");
//        sports.initLexique("./lexique-sport.txt");
//
//        Categorie politique = new Categorie("POLITIQUE");
//        politique.initLexique("./lexique-politique.txt");
//
//        Categorie culture = new Categorie("CULTURE");
//        culture.initLexique("./lexique-culture.txt");
//
//        Categorie environmentScience = new Categorie("ENVIRONNEMENT-SCIENCES");
//        environmentScience.initLexique("./lexique-environnement-sciences.txt");



        //génération lexique automatique

        Categorie sports = new Categorie("SPORTS");
        //generationLexique(depeches,sports.getNom(),"./lexique-sport.txt");
        sports.initLexique("./lexique-sport.txt");

        Categorie politique = new Categorie("POLITIQUE");
        //generationLexique(depeches,politique.getNom(),"./lexique-politique.txt");
        politique.initLexique("./lexique-politique.txt");

        Categorie culture = new Categorie("CULTURE");
        //generationLexique(depeches,culture.getNom(),"./lexique-culture.txt");
        culture.initLexique("./lexique-culture.txt");

        Categorie environnement_sciences = new Categorie("ENVIRONNEMENT-SCIENCES");
        //generationLexique(depeches,environnement_sciences.getNom(),"./lexique-environnement-sciences.txt");
        environnement_sciences.initLexique("./lexique-environnement-sciences.txt");

        Categorie economie = new Categorie("ECONOMIE");
        //generationLexique(depeches,economie.getNom(),"./lexique-economie.txt");
        economie.initLexique("./lexique-economie.txt");


        //test indiceIndicePourChaine

//        System.out.println(UtilitairePaireChaineEntier.indicePourChaine(sports.getLexique(), sports.getLexique().get(0).getChaine()));

        //test initLexique

//        for (int i = 0; i < Economie.getLexique().size(); i++) {
//            System.out.println(Economie.getLexique().get(i).toString());
//        }


        //test score

//        System.out.println("");
//        System.out.println("Score pour EnvironnementScience avec la premiere depeche : " + environmentScience.score(depeches.get(0)));
//        System.out.println("");


        //test EntierPourChaine

//        String unMot;
//        int unEntier;
//        Scanner lecteur = new Scanner(System.in);
//        System.out.println("donnez un mot présent dans la catégorie : ");
//        unMot = lecteur.nextLine();
//        unEntier = UtilitairePaireChaineEntier.entierPourChaine(Economie.getLexique(), unMot);
//        System.out.println("l'entier pour " + unMot + " est " + unEntier);
//        System.out.println("");



        //test de chaineMax

//        System.out.println("ChaineMax pour  : " + UtilitairePaireChaineEntier.chaineMax(economie.getLexique()));
//        System.out.println("");


        //test pour InitDico et calcul score

//        System.out.println("test pour InitDico et calcul score : ");
//        ArrayList<PaireChaineEntier> test = initDico(depeches, culture.getNom());
//        System.out.println(test);
//
//        System.out.println("calcule score : ");
//        calculScores(depeches, culture.getNom(), test);
//        System.out.println(test);


        //création fichier classement

        ArrayList<Categorie> categories = new ArrayList<>(Arrays.asList(environnement_sciences,culture,economie,politique,sports));

        classementDepeches(depeches, categories , "classement.txt");

        long endTime = System.currentTimeMillis();
        System.out.println("le code a été parcouru en : " + (endTime-startTime) + "ms");
    }
}

